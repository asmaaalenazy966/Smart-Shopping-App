# SmartShoppingApp (Semi-Complete Demo)

This package is prepared to help you upload a presentable graduation project to GitHub.
It contains simplified and working-ready snippets that show the core ideas:
- Mobile app (Xamarin) snippets
- API (ASP.NET Core) demo
- Admin website (static demo)
- MySQL schema
- ESP8266 sketch for sensor boxes (IoT)

Use Visual Studio to turn snippets into a working app. This package is ideal to showcase your skills on GitHub.

If you want, I can:
- Convert this package into a single ZIP you can download (I will do that now).
- Then guide you, step-by-step, how to upload it to GitHub from your phone.

